$(document).ready(function(){

if(window.location.href=="http://ankanbiswas.in/")
{

$("#sidebar").css({width:'100%'});

 
 $("#btnblog").click(function(){


    $("#sidebar").animate({width:'33.3333%'},'slow');



  });

}

  });
